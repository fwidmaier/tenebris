class Dual:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    @staticmethod
    def add(a, b):
        return a + b
